module.exports = {
  content: ["./src/**/*.php", "./src/**/*.js"]
}
