<div class="border-t mt-4 py-4">
  <div class="max-w-4xl px-4 mx-auto text-xs text-gray-400">Your footer content here.</div>
</div>

<?php wp_footer(); ?>
</body>
</html>