const ourColors = [
  { name: "blue", color: "#0d3b66" },
  { name: "orange", color: "#ee964b" },
  { name: "dark-orange", color: "#f95738" }
]

export default ourColors
