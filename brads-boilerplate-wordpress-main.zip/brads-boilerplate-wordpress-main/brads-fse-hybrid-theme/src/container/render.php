<div class="container container--narrow page-section generic-content">
  <?php echo $content; ?>
</div>